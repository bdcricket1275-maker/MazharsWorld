package com.mazharsworld.finance;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREF = "mazhars_world_v2";
    private static final String KEY_TX = "transactions";
    private static final String KEY_PIN = "pin_hash";

    private LinearLayout root, list, dashboard, reportBox;
    private TextView income, expense, invest, balance, reportTitle, empty;
    private Spinner monthSpinner;
    private ChartView chart;
    private SharedPreferences sp;
    private final int NAVY=Color.rgb(7,17,31), GOLD=Color.rgb(245,183,43),
            BG=Color.rgb(245,247,250), GREEN=Color.rgb(22,138,82),
            RED=Color.rgb(214,66,66), BLUE=Color.rgb(36,107,206),
            MUTED=Color.rgb(92,101,115);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences(PREF,0);
        if(!sp.contains(KEY_PIN)) showSetPin();
        else showPinLock();
    }

    private TextView tv(String s,float size,int c){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(c);
        t.setPadding(16,8,16,8); return t;
    }
    private GradientDrawable rounded(int color,float r){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g;
    }
    private Button action(String text,int color){
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setTextSize(13); b.setAllCaps(false); b.setBackground(rounded(color,22));
        b.setPadding(8,0,8,0);
        return b;
    }

    private void showSetPin(){
        final EditText pin=new EditText(this);
        pin.setHint("৪ সংখ্যার PIN");
        pin.setInputType(2|16);
        LinearLayout box=new LinearLayout(this); box.setPadding(28,4,28,4); box.addView(pin,new LinearLayout.LayoutParams(-1,60));
        // Single PIN setup dialog; invalid input keeps the dialog open.
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Mazhar's World সুরক্ষা")
                .setMessage("একটি ৪ সংখ্যার PIN দিন।")
                .setView(box).setCancelable(false)
                .create();
        d.setButton(AlertDialog.BUTTON_POSITIVE,"সেভ",(x,w)->{});
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String p=pin.getText().toString().trim();
            if(!p.matches("\\d{4}")) { pin.setError("৪ সংখ্যার PIN দিন"); return; }
            sp.edit().putString(KEY_PIN,hash(p)).apply(); d.dismiss(); build(); refresh();
        }));
        d.show();
    }

    private void showPinLock(){
        final EditText pin=new EditText(this);
        pin.setHint("PIN");
        pin.setInputType(2|16);
        LinearLayout box=new LinearLayout(this); box.setPadding(28,4,28,4); box.addView(pin,new LinearLayout.LayoutParams(-1,60));
        final AlertDialog d=new AlertDialog.Builder(this).setTitle("Mazhar's World")
                .setMessage("অ্যাপ খুলতে আপনার PIN দিন।").setView(box).setCancelable(false).create();
        d.setButton(AlertDialog.BUTTON_POSITIVE,"Unlock",(x,w)->{});
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(hash(pin.getText().toString()).equals(sp.getString(KEY_PIN,""))){ d.dismiss(); build(); refresh(); }
            else pin.setError("PIN সঠিক নয়");
        }));
        d.show();
    }

    private void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); setContentView(root);

        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(10,7,10,7); bar.setBackgroundColor(NAVY);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.mazhars_world_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); bar.addView(logo,new LinearLayout.LayoutParams(54,54));
        TextView title=tv("Mazhar's World",20,Color.WHITE); title.setTypeface(null,1);
        bar.addView(title,new LinearLayout.LayoutParams(0,62,1));
        Button menu=action("⋮",GOLD); menu.setTextColor(NAVY); bar.addView(menu,new LinearLayout.LayoutParams(48,48));
        menu.setOnClickListener(v->showMenu());
        root.addView(bar);

        ScrollView sv=new ScrollView(this); dashboard=new LinearLayout(this); dashboard.setOrientation(LinearLayout.VERTICAL);
        dashboard.setPadding(14,14,14,28); sv.addView(dashboard); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        TextView h=tv("আমার হিসাব",25,NAVY); h.setTypeface(null,1); dashboard.addView(h);
        dashboard.addView(tv("আয় • খরচ • Investment • অবশিষ্ট",13,MUTED));

        LinearLayout cards=new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL);
        dashboard.addView(cards);
        income=card("মোট আয়",GREEN); expense=card("মোট খরচ",RED); invest=card("মোট Investment",BLUE); balance=card("অবশিষ্ট",GOLD);
        cards.addView(income);cards.addView(expense);cards.addView(invest);cards.addView(balance);

        LinearLayout buttons=new LinearLayout(this); buttons.setGravity(Gravity.CENTER); dashboard.addView(buttons);
        Button ai=action("+ আয়",GREEN), ae=action("− খরচ",RED), av=action("+ Investment",BLUE);
        for(Button b:new Button[]{ai,ae,av}){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,54,1);p.setMargins(3,6,3,12);buttons.addView(b,p); }
        ai.setOnClickListener(v->editTransaction(-1,"আয়"));
        ae.setOnClickListener(v->editTransaction(-1,"খরচ"));
        av.setOnClickListener(v->editTransaction(-1,"Investment"));

        TextView rh=tv("মাসভিত্তিক রিপোর্ট",19,NAVY);rh.setTypeface(null,1);dashboard.addView(rh);
        reportBox=new LinearLayout(this); reportBox.setOrientation(LinearLayout.VERTICAL);
        reportBox.setBackground(rounded(Color.WHITE,24)); reportBox.setPadding(12,10,12,12);
        dashboard.addView(reportBox,new LinearLayout.LayoutParams(-1,-2));
        reportTitle=tv("",15,NAVY); reportTitle.setTypeface(null,1); reportBox.addView(reportTitle);
        monthSpinner=new Spinner(this);
        ArrayList<String> months=new ArrayList<>();
        Calendar m=Calendar.getInstance();
        for(int k=0;k<12;k++){ months.add(new SimpleDateFormat("MMMM yyyy",Locale.ENGLISH).format(m.getTime())); m.add(Calendar.MONTH,-1); }
        ArrayAdapter<String> ma=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months);
        monthSpinner.setAdapter(ma);
        reportBox.addView(monthSpinner,new LinearLayout.LayoutParams(-1,52));
        monthSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ updateReport(getData(),pos); }
        });
        chart=new ChartView(this); reportBox.addView(chart,new LinearLayout.LayoutParams(-1,260));
        dashboard.addView(tv("লেনদেনের ইতিহাস",19,NAVY)); 
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); dashboard.addView(list);
        empty=tv("এখনও কোনো লেনদেন নেই।",14,MUTED); empty.setGravity(Gravity.CENTER); dashboard.addView(empty);
    }

    private TextView card(String label,int c){
        TextView t=tv(label+"\n৳ 0",16,c);t.setTypeface(null,1);t.setPadding(18,15,18,15);
        t.setBackground(rounded(Color.WHITE,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,82);
        p.setMargins(0,6,0,6);t.setLayoutParams(p);return t;
    }

    private JSONArray getData(){
        try{return new JSONArray(sp.getString(KEY_TX,"[]"));}catch(Exception e){return new JSONArray();}
    }
    private void saveData(JSONArray a){sp.edit().putString(KEY_TX,a.toString()).apply();}

    private void editTransaction(int index,String type){
        JSONArray all=getData();
        JSONObject old=null;
        try{if(index>=0)old=all.getJSONObject(index);}catch(Exception ignored){}
        final EditText amount=new EditText(this); amount.setHint("টাকার পরিমাণ"); amount.setInputType(2|8192);
        final EditText category=new EditText(this); category.setHint(type.equals("খরচ")?"ক্যাটাগরি (যেমন বাজার)":"উৎস / কোথা থেকে");
        final EditText note=new EditText(this); note.setHint(type.equals("Investment")?"কোথায় বিনিয়োগ":"নোট (ঐচ্ছিক)");
        if(old!=null)try{
            amount.setText(String.valueOf(old.optDouble("amount",0)));
            category.setText(old.optString("category","")); note.setText(old.optString("note",""));
        }catch(Exception ignored){}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,0,24,0);
        box.addView(amount);box.addView(category);box.addView(note);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(index<0?type+" যোগ করুন":type+" সম্পাদনা").setView(box);
        b.setPositiveButton("সেভ",(d,w)->{
            try{
                double a=Double.parseDouble(amount.getText().toString().trim());
                if(a<=0)throw new Exception();
                JSONObject o=(old==null?new JSONObject():old);
                o.put("type",type);o.put("amount",a);o.put("category",category.getText().toString().trim());
                o.put("note",note.getText().toString().trim());
                if(old==null)o.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date()));
                if(index<0)all.put(0,o);else all.put(index,o);
                saveData(all);refresh();
            }catch(Exception e){Toast.makeText(this,"সঠিক টাকার পরিমাণ দিন",Toast.LENGTH_SHORT).show();}
        }).setNegativeButton("বাতিল",null);
        if(index>=0)b.setNeutralButton("Delete",(d,w)->deleteTransaction(index));
        b.show();
    }

    private void deleteTransaction(int index){
        new AlertDialog.Builder(this).setTitle("লেনদেন মুছবেন?")
                .setMessage("এই তথ্যটি স্থায়ীভাবে মুছে যাবে।")
                .setNegativeButton("বাতিল",null).setPositiveButton("মুছুন",(d,w)->{
                    JSONArray a=getData();a.remove(index);saveData(a);refresh();
                }).show();
    }

    private void refresh(){
        if(list==null)return;
        JSONArray a=getData(); double in=0,ex=0,iv=0;
        list.removeAllViews(); empty.setVisibility(a.length()==0?View.VISIBLE:View.GONE);
        for(int i=0;i<a.length();i++)try{
            JSONObject o=a.getJSONObject(i);String type=o.optString("type");double val=o.optDouble("amount");
            if(type.equals("আয়"))in+=val;else if(type.equals("খরচ"))ex+=val;else iv+=val;
            addRow(i,o);
        }catch(Exception ignored){}
        income.setText("মোট আয়\n৳ "+money(in));expense.setText("মোট খরচ\n৳ "+money(ex));
        invest.setText("মোট Investment\n৳ "+money(iv));balance.setText("অবশিষ্ট\n৳ "+money(in-ex-iv));
        updateReport(a, monthSpinner==null?0:monthSpinner.getSelectedItemPosition());
    }

    private void addRow(int index,JSONObject o){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,7,6,7);
        row.setBackground(rounded(Color.WHITE,18));
        LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);
        String type=o.optString("type"), cat=o.optString("category"), note=o.optString("note");
        int c=type.equals("আয়")?GREEN:type.equals("খরচ")?RED:BLUE;
        TextView top=tv(type+"  •  ৳ "+money(o.optDouble("amount")),15,c);top.setTypeface(null,1);
        TextView sub=tv(o.optString("date")+(cat.isEmpty()?"":"  •  "+cat)+(note.isEmpty()?"":"  •  "+note),12,MUTED);
        text.addView(top);text.addView(sub);row.addView(text,new LinearLayout.LayoutParams(0,68,1));
        Button edit=action("Edit",NAVY);row.addView(edit,new LinearLayout.LayoutParams(60,48));edit.setOnClickListener(v->editTransaction(index,type));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,4,0,4);row.setLayoutParams(rp);list.addView(row);
    }

    private void updateReport(JSONArray a,int monthOffset){
        Calendar selected=Calendar.getInstance(); selected.add(Calendar.MONTH,-Math.max(0,monthOffset));
        String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(selected.getTime());
        double in=0,ex=0,iv=0;int count=0;
        try{for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optString("date").startsWith(month)){
            count++;double v=o.optDouble("amount");if(o.optString("type").equals("আয়"))in+=v;else if(o.optString("type").equals("খরচ"))ex+=v;else iv+=v;}}}catch(Exception ignored){}
        reportTitle.setText((monthOffset==0?"এই মাস • ":"নির্বাচিত মাস • ")+new SimpleDateFormat("MMMM yyyy",Locale.ENGLISH).format(selected.getTime())+
                "\nআয় ৳ "+money(in)+"   |   খরচ ৳ "+money(ex)+"   |   Investment ৳ "+money(iv)+
                "\nলেনদেন: "+count+"   •   অবশিষ্ট ৳ "+money(in-ex-iv));
        chart.setValues(in,ex,iv);
    }

    private void showMenu(){
        final String[] items={"🔐 PIN পরিবর্তন","💾 Backup তৈরি","♻ Restore Backup","📊 রিপোর্ট রিফ্রেশ"};
        new AlertDialog.Builder(this).setTitle("Menu").setItems(items,(d,w)->{
            if(w==0)changePin();else if(w==1)backup();else if(w==2)restore();else refresh();
        }).show();
    }

    private void changePin(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,0,24,0);
        EditText old=new EditText(this);old.setHint("বর্তমান PIN");old.setInputType(2|16);
        EditText np=new EditText(this);np.setHint("নতুন ৪ সংখ্যার PIN");np.setInputType(2|16);box.addView(old);box.addView(np);
        new AlertDialog.Builder(this).setTitle("PIN পরিবর্তন").setView(box).setNegativeButton("বাতিল",null)
                .setPositiveButton("সেভ",(d,w)->{
                    if(hash(old.getText().toString()).equals(sp.getString(KEY_PIN,""))&&np.getText().toString().matches("\\d{4}"))
                        sp.edit().putString(KEY_PIN,hash(np.getText().toString())).apply();
                    else Toast.makeText(this,"PIN সঠিক নয়",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void backup(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"MazharsWorld-Backup.json");
        startActivityForResult(i,100);
    }
    private void restore(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,101);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        try{
            Uri u=data.getData();
            if(req==100){
                JSONObject out=new JSONObject();out.put("app","Mazhar's World");out.put("version",2);out.put("transactions",getData());
                OutputStream os=getContentResolver().openOutputStream(u);os.write(out.toString(2).getBytes(StandardCharsets.UTF_8));os.close();
                Toast.makeText(this,"Backup তৈরি হয়েছে",Toast.LENGTH_SHORT).show();
            }else{
                InputStream is=getContentResolver().openInputStream(u);ByteArrayOutputStream bo=new ByteArrayOutputStream();
                byte[] buf=new byte[4096];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);is.close();
                JSONObject in=new JSONObject(bo.toString("UTF-8"));JSONArray tx=in.getJSONArray("transactions");saveData(tx);refresh();
                Toast.makeText(this,"Backup Restore হয়েছে",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Backup/Restore করা যায়নি",Toast.LENGTH_LONG).show();}
    }

    private String hash(String s){
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] b=md.digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte q:b)x.append(String.format(Locale.US,"%02x",q));return x.toString();}catch(Exception e){return s;}
    }
    private String money(double d){return String.format(Locale.US,"%,.2f",d);}

    private class ChartView extends View {
        Paint p=new Paint(3); double a=0,e=0,i=0;
        ChartView(Context c){super(c);p.setTypeface(Typeface.DEFAULT);}
        void setValues(double aa,double ee,double ii){a=aa;e=ee;i=ii;invalidate();}
        protected void onDraw(Canvas c){
            super.onDraw(c);float w=getWidth(),h=getHeight();p.setColor(Color.rgb(235,238,243));p.setStrokeWidth(1);
            for(int k=1;k<=4;k++)c.drawLine(20,h-35-k*(h-60)/5,w-20,h-35-k*(h-60)/5,p);
            double max=Math.max(1,Math.max(a,Math.max(e,i)));float base=h-35, maxH=h-65;
            float[] vals={(float)a,(float)e,(float)i};int[] cols={GREEN,RED,BLUE};String[] labels={"আয়","খরচ","Investment"};
            for(int k=0;k<3;k++){float bh=(float)(vals[k]/max*maxH);float x=55+k*(w-110)/3;float bw=Math.min(72,(w-100)/5f);
                p.setColor(cols[k]);c.drawRoundRect(x,base-bh,x+bw,base,14,14,p);
                p.setColor(NAVY);p.setTextSize(12);c.drawText(labels[k],x,base+24,p);
                p.setTextSize(11);c.drawText("৳ "+money(vals[k]),x,Math.max(18,base-bh-8),p);
            }
        }
    }
}
