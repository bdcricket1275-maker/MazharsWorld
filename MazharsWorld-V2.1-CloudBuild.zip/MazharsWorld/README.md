# Mazhar's World — Android Finance App V2.1

Personal offline finance/accounting app in Bengali with ৳ support.

## Included
- 🔐 4-digit PIN lock and PIN change
- 📊 Dashboard: income, expenses, investments, balance
- 📅 Monthly report selector for the latest 12 months
- 📈 Visual monthly income/expense/investment chart
- ➕ Add income, expense and investment
- ✏️ Edit and delete transactions
- 🧾 Transaction history
- 💾 JSON Backup / ♻ Restore through Android document picker
- 🇧🇩 Bengali labels and Bangladeshi Taka (৳)
- 📱 Offline local storage
- ✨ Dark navy + gold polished UI with Mazhar's World logo
- ☁️ GitHub Actions cloud-build workflow included
- No third-party runtime libraries

## Build
The project uses Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 23 and Java 17.

### Cloud build
Upload this project to a GitHub repository. The included `.github/workflows/build-apk.yml` automatically builds a debug APK on push to `main`/`master`, or manually from the Actions tab with **Build Mazhar's World APK**. The APK is published as the `MazharsWorld-debug-apk` workflow artifact.

### Package
`com.mazharsworld.finance`

### Version
`2.1`
